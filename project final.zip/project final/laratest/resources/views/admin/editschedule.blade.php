<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

   
    <form action="{{route('editschedule',['id' => $busschedule->id])}}" method="post">
        {{csrf_field()}}
        <h3>Add Bus </h3>
        <label for="id">id</label><br>
		<input type="text" name="id" readonly value="{{$busschedule['id']}}"><br>
        <label for="">name</label><br>
        <input type="text" name="name" value="{{$busschedule['name']}}" required><br>
        <label for="">operator</label><br>
        <input type="text" name="operator" value="{{$busschedule['operator']}}" required><br>
        <label for="">Seat Row</label><br>
        <input type="number" name="seat_row" value="{{$busschedule['seat_row']}}" required><br>
        <label for="">Seat Column</label><br>
        <input type="number" name="seat_column" value="{{$busschedule['seat_column']}}" required><br>
        
        <label for="route">Route</label><br>
        <input type="text" name="route" value="{{$busschedule['route']}}" required><br>
        <label for="fare">Fare</label><br>
        <input type="text" name="fare" value="{{$busschedule['fare']}}" required><br>
        <label for="arrival">Arrival</label><br>
        <input type="time" name="arrival" value="{{$busschedule['arrival']}}" required><br>
        <label for="departure">Departure</label><br>
        <input type="time" name="departure" value="{{$busschedule['departure']}}" required><br>
        <button type="submit">Submit</button>
        
    </form>
</body>
</html>
