<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

   
    <form action="{{route('addschedule')}}" method="post">
        {{csrf_field()}}
        <h3>Add Bus </h3>
        <label for="">name</label><br>
        <input type="text" name="name" required><br>
        <label for="">operator</label><br>
        <input type="text" name="operator" required><br>
        <label for="">Seat Row</label><br>
        <input type="number" name="seat_row" required><br>
        <label for="">Seat Column</label><br>
        <input type="number" name="seat_column" required><br>
        <label for="route">Route</label><br>
        <input type="text" name="route" required><br>
        <label for="fare">Fare</label><br>
        <input type="text" name="fare" required><br>
        <label for="arrival">Arrival</label><br>
        <input type="time" name="arrival" required><br>
        <label for="departure">Departure</label><br>
        <input type="time" name="departure" required><br>
        <button type="submit">Submit</button>
        
    </form>
	<a href="{{route('admin.index')}}">Back</a>
</body>
</html>
