<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
 <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<body>
    <br><h1><b>Bus Schedule</b></h1>
   <a href="{{route('addschedule')}}">Add Schedule</a>
	<br><br><br>
	
	<table border="1">
		<tr>
		     <th>Id</th>
			<th>Name</th>
			<th>operator</th>
            <th>Seat Row</th>
            <th>Seat Column</th>
            <th>Route</th>
			<th>Fare</th>
			<th>Departure</th>
			<th>Arrival</th>
			<th>Action</th>
		</tr>

		@foreach($allBusschedule as $busschedule)
		<tr>
		     <td>{{$busschedule['id']}}</td>
			<td>{{$busschedule['name']}}</td>
			<td>{{$busschedule['operator']}}</td>
			<td>{{$busschedule['seat_row']}}</td>
			<td>{{$busschedule['seat_column']}}</td>
			<td>{{$busschedule['route']}}</td>
			<td>{{$busschedule['fare']}}</td>
			<td>{{$busschedule['arrival']}}</td>
			<td>{{$busschedule['departure']}}</td>
			<td>
                <a href="{{route('editschedule', $busschedule['id'])}}">Edit</a>
			</td>
			<td>
			    <a href="{{route('deleteschedule', $busschedule['id'])}}">Delete</a>
                
			</td>
			
		</tr>
		@endforeach
	</table>
	<a href="{{route('admin.index')}}">Back</a>

</body>
</html>

