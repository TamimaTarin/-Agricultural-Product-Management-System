<!DOCTYPE html>
<html>
<head>
	<title>Login Page</title>
</head>
<body>
	<h1>Log in</h1>
	<form method="post">
		<!-- <input type="hidden" name="_token" value="{{csrf_token()}}"> -->
		{{csrf_field()}}
		<table>
			<tr>
				<td>E-mail: </td><td><input type="email" name="email"></td>
			</tr>
			<tr>
				<td>Password: </td><td><input type="password" name="password"></td>
			</tr>
			<tr><td><button type="submit">Login</button></td></tr>
			<br>
			<br><a href="{{route('registration')}}">Registration</a>
			
		</table>
		<h3>{{session('msg')}}</h3>
	</form>
</body>
</html>