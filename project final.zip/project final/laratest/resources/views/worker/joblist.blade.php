<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
 <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<body>
    <br><h1><b>joblist</b></h1>
  
	<br><br><br>
	
	<table border="1">
		<tr>
		     <th>JobId</th>
			<th>PostedBy</th>
			<th>Status</th>
            <th>Title</th>
            <th>Description</th>
            <th>Budget</th>
			<th>JobType</th>
			<th>Action</th>
		</tr>

		@foreach($allJobList as $joblist)
		<tr>
		     <td>{{$joblist['JobId']}}</td>
			<td>{{$joblist['PostedBy']}}</td>
			<td>{{$joblist['Status']}}</td>
			<td>{{$joblist['Title']}}</td>
			<td>{{$joblist['Description']}}</td>
			<td>{{$joblist['Budget']}}</td>
			<td>{{$joblist['JobType']}}</td>
			
			<td>
                <a href="{{route('bidinglist', $joblist['id'])}}">Bid</a>
			</td>
			<td>
			    
                
			</td>
			
		</tr>
		@endforeach
	</table>
	<a href="{{route('worker.index')}}">Back</a>

</body>
</html>

