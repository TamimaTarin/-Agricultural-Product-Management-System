<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

   
    <form action="{{route('msgtoadmin')}}" method="post">
        {{csrf_field()}}
        <h3>msg to admin </h3>
      
        <label for="">message</label><br>
        <input type="text" name="Name" required><br>
        <button type="submit">Submit</button>
        
    </form>

</body>
</html>
