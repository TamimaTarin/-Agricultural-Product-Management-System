<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

   
    <form action="{{route('editprofile',['id' => $user->id])}}" method="post">
        {{csrf_field()}}
        <h3>profile </h3>
        <label for="id">id</label><br>
		<input type="number" name="id" readonly value="{{$user['id']}}"><br>
        <label for="">name</label><br>
        <input type="text" name="Name" value="{{$user['Name']}}" required><br>
        <label for="">Email</label><br>
        <input type="text" name="Email" value="{{$user['Email']}}" required><br>
        <label for="">Password</label><br>
        <input type="text" name="Password" value="{{$user['Password']}}" required><br>
        <label for="">Type</label><br>
        <input type="text" name="type" value="{{$user['type']}}" required><br>
        <label for="">Gender</label><br>
        <input type="text" name="Gender" value="{{$user['Gender']}}" required><br>
        <label for="">Addess</label><br>
        <input type="" name="Address" value="{{$user['Address']}}" required><br>
        <label for="">WorkType</label><br>
        <input type="text" name="WorkType" value="{{$user['WorkType']}}" required><br>
        <button type="submit">Submit</button>
        
    </form>
</body>
</html>
