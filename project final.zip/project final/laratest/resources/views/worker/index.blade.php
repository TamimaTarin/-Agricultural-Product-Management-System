<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<h1>welcome to worker homepage</h1>
	<!-- <form method="post"> -->
		<!-- <input type="hidden" name="_token" value="{{csrf_token()}}"> -->
		{{csrf_field()}}
		Hey <b>{{session('Email')}}</b><br><br><br>
		<br><a href="{{route('ownprofile')}}">ownprofile</a>
    	<br><a href="{{route('joblist')}}">joblist</a>
    	<br><a href="{{route('bidinglist')}}">biding list</a>
    	<br><a href="{{route('msgtoadmin')}}">message to admin</a>
    	
		<!-- <br><a href="/logout">Logout</a>  -->
		<br><button id='logout' onclick="doRedirect()">Logout</button>
		<!-- <br><a href="/logout">deactivate</a>  -->
		<br><button id='logout' onclick="doRedirect()">deactivate</button>
	</form>
</body>
<script type="text/javascript">
	function doRedirect(){
		window.location.replace("/logout");
	}

</script>
</html>