<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/



Route::get('/', function () {
    return view('welcome');
});

//Login Controller
Route::get('/login','LoginController@index');
Route::post('/login','LoginController@verify');
Route::get('/login/registration','LoginController@registration')->name('registration');
Route::post('/login/registration','LoginController@store')->name('registration');

//cv
Route::get('/system/nonactive','CvController@index')->name('nonactive.index');
Route::get('/nonactive/cv','CvController@cv')->name('cv');
Route::post('/nonactive/cv','CvController@store')->name('cv');
Route::get('/nonactive/showcvinfo', 'CvController@showcvinfo')->name('showcvinfo');

//Home Controller
Route::get('/home','HomeController@index')->name('home.index');

//worker
Route::get('/system/worker','WorkerController@index')->name('worker.index');
Route::get('/system/ownprofile', 'WorkerController@profile')->name('ownprofile');
Route::get('/system/joblist', 'JobController@index')->name('joblist');
Route::get('/system/bidinglist', 'JobController@bid')->name('bidinglist');
Route::get('/system/msgtoadmin', 'MessageController@index')->name('msgtoadmin');
Route::get('/system/bidinglist{BidId}', 'JobController@delete')->name('deletebid');

Route::get('/system/viewbus/{id}/editschedule', 'ScheduleController@edit')->name('editschedule');
Route::post('/system/viewbus/{id}/editschedule', 'ScheduleController@update')->name('editschedule');
Route::get('/system/viewbus{id}', 'ScheduleController@delete')->name('deleteschedule');

//Admin 
Route::get('/system/admin','AdminController@index')->name('admin.index');
Route::get('/system/buses/addschedule', 'ScheduleController@add')->name('addschedule');
Route::post('/system/buses/addschedule', 'ScheduleController@store')->name('addschedule');
Route::get('/system/viewbus', 'ScheduleController@index')->name('viewbus');
Route::get('/system/ownprofile', 'ProfileController@index')->name('ownprofile');
Route::get('/system/viewbus/{id}/editschedule', 'ScheduleController@edit')->name('editschedule');
Route::post('/system/viewbus/{id}/editschedule', 'ScheduleController@update')->name('editschedule');
Route::get('/system/viewbus{id}', 'ScheduleController@delete')->name('deleteschedule');


//Logout Controller
Route::get('/logout', 'logoutController@index');