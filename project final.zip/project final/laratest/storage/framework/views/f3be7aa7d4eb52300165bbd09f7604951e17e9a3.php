<!DOCTYPE html>
<html>
<head>
	<title>Login Page</title>
</head>
<body>
	<h1>Log in</h1>
	<form method="post">
		<!-- <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"> -->
		<?php echo e(csrf_field()); ?>

		<table>
			<tr>
				<td>E-mail: </td><td><input type="email" name="email"></td>
			</tr>
			<tr>
				<td>Password: </td><td><input type="password" name="password"></td>
			</tr>
			<tr><td><button type="submit">Login</button></td></tr>
		</table>
		<h3><?php echo e(session('msg')); ?></h3>
	</form>
</body>
</html><?php /**PATH C:\Users\USER\Desktop\atp3(assignmen)\laratest\resources\views/login/index.blade.php ENDPATH**/ ?>