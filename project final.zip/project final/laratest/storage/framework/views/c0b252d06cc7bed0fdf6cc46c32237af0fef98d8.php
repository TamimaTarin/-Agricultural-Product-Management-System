<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

   
    <form action="<?php echo e(route('cv')); ?>" method="post">
        <?php echo e(csrf_field()); ?>

        <h3>Cvform </h3>
      
        <label for="">FirstName</label><br>
        <input type="text" name="FirstName" required><br>
        <label for="">LastName</label><br>
        <input type="text" name="LastName" required><br>
        <label for="">Phoneno</label><br>
        <input type="text" name="Phoneno" required><br>
		<label for="">EduBack</label><br>
		<input type="radio" name="EduBack"
		<?php if (isset($EduBack) && $EduBack=="Bsc") echo "checked";?>
		value="Bsc">Bsc<br>
		<input type="radio" name="EduBack"
		<?php if (isset($EduBack) && $EduBack=="msc") echo "checked";?>
		value="msc">Msc<br>
		<label for="">Address</label><br>
        <input type="text" name="Address" required><br>
        <label for="">Skill</label><br>
        <input type="text" name="Skill" required><br>
		<label for="">Experience</label><br>
        <input type="text" name="Experience" required><br>
			
		<br><br>
        <button type="submit">Submit</button><br>
        <a href="<?php echo e(route('nonactive.index')); ?>">Back</a>
    </form>

</body>
</html>
<?php /**PATH C:\Users\USER\Desktop\project final\laratest\resources\views/nonactive/cv.blade.php ENDPATH**/ ?>