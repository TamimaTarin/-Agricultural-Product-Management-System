<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
 <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<body>
    <br><h1><b>joblist</b></h1>
  
	<br><br><br>
	
	<table border="1">
		<tr>
		     <th>JobId</th>
			<th>PostedBy</th>
			<th>Status</th>
            <th>Title</th>
            <th>Description</th>
            <th>Budget</th>
			<th>JobType</th>
			<th>Action</th>
		</tr>

		<?php $__currentLoopData = $allJobList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $joblist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
		     <td><?php echo e($joblist['JobId']); ?></td>
			<td><?php echo e($joblist['PostedBy']); ?></td>
			<td><?php echo e($joblist['Status']); ?></td>
			<td><?php echo e($joblist['Title']); ?></td>
			<td><?php echo e($joblist['Description']); ?></td>
			<td><?php echo e($joblist['Budget']); ?></td>
			<td><?php echo e($joblist['JobType']); ?></td>
			
			<td>
                <a href="<?php echo e(route('bidinglist', $joblist['id'])); ?>">Bid</a>
			</td>
			<td>
			    
                
			</td>
			
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>
	<a href="<?php echo e(route('worker.index')); ?>">Back</a>

</body>
</html>

<?php /**PATH C:\Users\USER\Desktop\project final\laratest\resources\views/worker/joblist.blade.php ENDPATH**/ ?>