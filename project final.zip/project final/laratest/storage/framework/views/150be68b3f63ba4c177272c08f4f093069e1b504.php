<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

   
    <form action="<?php echo e(route('editprofile',['id' => $user->id])); ?>" method="post">
        <?php echo e(csrf_field()); ?>

        <h3>profile </h3>
        <label for="id">id</label><br>
		<input type="number" name="id" readonly value="<?php echo e($user['id']); ?>"><br>
        <label for="">name</label><br>
        <input type="text" name="Name" value="<?php echo e($user['Name']); ?>" required><br>
        <label for="">Email</label><br>
        <input type="text" name="Email" value="<?php echo e($user['Email']); ?>" required><br>
        <label for="">Password</label><br>
        <input type="text" name="Password" value="<?php echo e($user['Password']); ?>" required><br>
        <label for="">Type</label><br>
        <input type="text" name="type" value="<?php echo e($user['type']); ?>" required><br>
        <label for="">Gender</label><br>
        <input type="text" name="Gender" value="<?php echo e($user['Gender']); ?>" required><br>
        <label for="">Addess</label><br>
        <input type="" name="Address" value="<?php echo e($user['Address']); ?>" required><br>
        <label for="">WorkType</label><br>
        <input type="text" name="WorkType" value="<?php echo e($user['WorkType']); ?>" required><br>
        <button type="submit">Submit</button>
        
    </form>
</body>
</html>
<?php /**PATH C:\Users\USER\Desktop\project final\laratest\resources\views/worker/editprofile.blade.php ENDPATH**/ ?>