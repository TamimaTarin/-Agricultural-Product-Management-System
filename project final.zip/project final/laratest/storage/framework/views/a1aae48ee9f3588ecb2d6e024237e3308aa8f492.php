<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<h1>welcome.Your account is not actiavated yet.Please Fillup the cv form first.</h1>
	<!-- <form method="post"> -->
		<!-- <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"> -->
		<?php echo e(csrf_field()); ?>

		Hey <b><?php echo e(session('Email')); ?></b><br><br>
		<br><a href="<?php echo e(route('cv')); ?>">Cv</a><br>
    
    	
		<!-- <br><a href="/logout">Logout</a>  -->
		<br><button id='logout' onclick="doRedirect()">Logout</button>
	</form>
</body>
<script type="text/javascript">
	function doRedirect(){
		window.location.replace("/logout");
	}

</script>
</html><?php /**PATH C:\Users\USER\Desktop\project final\laratest\resources\views/nonactive/index.blade.php ENDPATH**/ ?>