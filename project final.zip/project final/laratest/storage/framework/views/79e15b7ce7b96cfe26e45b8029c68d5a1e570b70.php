<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

   
    <form action="<?php echo e(route('registration')); ?>" method="post">
        <?php echo e(csrf_field()); ?>

        <h3>Add Bus </h3>
      
        <label for="">Name</label><br>
        <input type="text" name="Name" required><br>
        <label for="">Email</label><br>
        <input type="text" name="Email" required><br>
        <label for="">Password</label><br>
        <input type="text" name="Password" required><br>
		<label for="">Type:</label><br>
		<input type="radio" name="type"
		<?php if (isset($type) && $type=="admin") echo "checked";?>
		value="admin">admin<br>
		<input type="radio" name="type"
		<?php if (isset($type) && $type=="worker") echo "checked";?>
		value="worker">worker<br>
		<label for="">Gender:</label><br>
		<input type="radio" name="Gender"
		<?php if (isset($Gender) && $Gender=="female") echo "checked";?>
		value="female">female<br>
		<input type="radio" name="Gender"
		<?php if (isset($Gender) && $Gender=="male") echo "checked";?>
		value="male">male<br>
		<input type="radio" name="Gender"
		<?php if (isset($Gender) && $Gender=="other") echo "checked";?>
		value="other">other<br><br>
		<label for="">Address</label><br>
        <input type="text" name="Address" required><br>
        <label for="">WorkType</label><br>
        <input type="text" name="WorkType" required><br>
		
			
		<br><br>
        <button type="submit">Submit</button>
        
    </form>

</body>
</html>
<?php /**PATH C:\Users\USER\Desktop\project final\laratest\resources\views/login/registration.blade.php ENDPATH**/ ?>