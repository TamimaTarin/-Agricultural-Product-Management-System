<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
 <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<body>
    <br><h1><b>customerinfo</b></h1>
  
	<br><br><br>
	
	<table border="1">
		<tr>
		     <th>id</th>
			<th>customename</th>
			<th>email</th>
            <th>address</th>
            <th>phoneno</th>
			<th>Action</th>
		</tr>

		<?php $__currentLoopData = $allCustomer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
		     <td><?php echo e($customer['id']); ?></td>
			<td><?php echo e($customer['customername']); ?></td>
			<td><?php echo e($customer['email']); ?></td>
			<td><?php echo e($customer['address']); ?></td>
			<td><?php echo e($customer['phoneno']); ?></td>
			<td>
                <a href="<?php echo e(route('msgtocustomer', $customer['id'])); ?>">message</a>
			</td>
			
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>
	<a href="<?php echo e(route('admin.index')); ?>">Back</a>

</body>
</html>

<?php /**PATH C:\Users\USER\Desktop\project final\laratest\resources\views/worker/details.blade.php ENDPATH**/ ?>