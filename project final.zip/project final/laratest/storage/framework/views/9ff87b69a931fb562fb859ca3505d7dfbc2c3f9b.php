<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
 <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<body>
    <br><h1><b>bidlist</b></h1>
  
	<br><br><br>
	
	<table border="1">
		<tr>
		     <th>id</th>
			<th>JobId</th>
			<th>BidBy</th>
            <th>Description</th>
			<th>Action</th>
		</tr>

		<?php $__currentLoopData = $allBidingList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bidinglist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
		     <td><?php echo e($bidinglist['id']); ?></td>
			<td><?php echo e($bidinglist['JobId']); ?></td>
			<td><?php echo e($bidinglist['BidBy']); ?></td>
			<td><?php echo e($bidinglist['Description']); ?></td>
			<td>
			    <a href="<?php echo e(route('deletebid', $bidinglist['id'])); ?>">Cancel</a>
                
			</td>
			
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>
	<a href="<?php echo e(route('worker.index')); ?>">Back</a>

</body>
</html>

<?php /**PATH C:\Users\USER\Desktop\project final\laratest\resources\views/worker/bidinglist.blade.php ENDPATH**/ ?>