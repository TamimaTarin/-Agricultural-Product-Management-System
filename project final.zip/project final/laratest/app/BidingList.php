<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class bidinglist extends Model
{
     public $timestamps = false;
}