<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class joblist extends Model
{
     public $timestamps = false;
}