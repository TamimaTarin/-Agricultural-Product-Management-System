<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Http\Request;
use App\Busschedule;

class ScheduleController extends BaseController
{
    public function index(){
        $allBusschedule = Busschedule::all();
        return view('admin.viewbus',['allBusschedule'=>$allBusschedule]);
    }
    public function add()
    {        
                    
        return view('admin.addschedule');
    }
    public function store(Request $request)
    {
		
		$busschedule = new Busschedule();
        $busschedule->name =$request->name;        
        $busschedule->operator =$request->operator;        
        $busschedule->seat_row =$request->seat_row;
        $busschedule->seat_column =$request->seat_column;
        $busschedule->route =$request->route;
        $busschedule->fare =$request->fare;
        $busschedule->arrival =$request->arrival;
        $busschedule->departure =$request->departure;
        $busschedule->save();
       return view('admin.index');
    }
    public function edit($id)
    {
        $busschedule = Busschedule::where('id', $id)->first();

        return view('admin.editSchedule', compact('busschedule'));
    }

    public function update(Request $request, $id)
    {
        $busschedule = Busschedule::find($id);
        $busschedule->name =$request->name;        
        $busschedule->operator =$request->operator;        
        $busschedule->seat_row =$request->seat_row;
        $busschedule->seat_column =$request->seat_column;
        $busschedule->route =$request->route;
        $busschedule->fare =$request->fare;
        $busschedule->arrival =$request->arrival;
        $busschedule->departure =$request->departure;
        $busschedule->save();
        //return view('admin.index');
		$allBusschedule = Busschedule::all();
        return view('admin.viewbus',['allBusschedule'=>$allBusschedule]);

    }
    public function delete($id)
    {        
        
        $busschedule = Busschedule::where('id', $id)->first();
        $busschedule->delete();
    }

    
}
