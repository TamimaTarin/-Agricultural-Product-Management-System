<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Http\Request;
use App\User;
use App\Register;
use App\Login;
use App\Customer;
class WorkerController extends BaseController
{
   public function index(){
    	return view('worker.index');
    }
	public function show(){
        $allUser = User::all();
        return view('worker.ownprofile',['allUser'=>$allUser]);
    }
	public function showdetails(){
        $allCustomer = Customer::all();
        return view('worker.details',['allCustomer'=>$allCustomer]);
    }
	 public function message(){
    	return view('worker.msgtocustomer');
    }
    public function edit($id)
    {
        $user = User::where('id', $id)->first();

        return view('worker.editprofile', compact('user'));
    }

    public function update(Request $request, $id)
    {
        $user = User::find($id);
        $user->Name =$request->Name;        
        $user->Email =$request->Email;        
        $user->Password=$request->Password;
        $user->type =$request->type;
        $user->Gender=$request->Gender;
        $user->Address =$request->Address;
        $user->WorkType=$request->WorkType;
       
        $user->save();
        //return view('admin.index');
		$allUser = User::all();
        return view('worker.ownprofile',['allUser'=>$allUser]);

    }
    
}
