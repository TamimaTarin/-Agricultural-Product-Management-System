<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Http\Request;
use App\JobList;
use App\BidingList;

class JobController extends BaseController
{
    public function index(){
        $allJobList = JobList::all();
        return view('worker.joblist',['allJobList'=>$allJobList]);
    }
	public function bid(){
        $allBidingList = BidingList::all();
        return view('worker.bidinglist',['allBidingList'=>$allBidingList]);
    }
   
    public function delete($id)
    {        
        
        $bidinglist = BidingList::where('id', $id)->first();
        $bidinglist->delete();
		$allBidingList = BidingList::all();
        return view('worker.bidinglist',['allBidingList'=>$allBidingList]);
    }

    
}
