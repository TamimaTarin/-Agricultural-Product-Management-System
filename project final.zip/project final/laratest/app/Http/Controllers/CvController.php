<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Http\Request;
use App\User;
use App\Register;
use App\Login;
use App\Cv;

class CvController extends BaseController
{
    public function index(){
    	return view('nonactive.index');
    }
	public function cv(){
    	return view('nonactive.cv');
    }
	public function store(Request $request)
    {
		
		$cv = new Cv();
        $cv->FirstName =$request->FirstName;        
        $cv->LastName =$request->LastName;        
        $cv->Phoneno =$request->Phoneno;        
        $cv->EduBack =$request->EduBack;
        $cv->Address =$request->Address;
        $cv->Skill =$request->Skill;
        $cv->Experience =$request->Experience;
       
        $cv->save();
	
	    return view('nonactive.index');
    }
	
   
}
