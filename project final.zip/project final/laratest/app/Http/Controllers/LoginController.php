<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Http\Request;
use App\User;
use App\Register;
use App\Login;

class LoginController extends BaseController
{
    public function index(){
    	return view('login.index');
    }
	public function registration(){
    	return view('login.registration');
    }
	public function store(Request $request)
    {
		
		$user = new User();
        $user->Name =$request->Name;        
        $user->Email =$request->Email;        
        $user->Password =$request->Password;
        $user->type =$request->type;
        $user->Gender =$request->Gender;
        $user->AccountStatus ="deactivate";
        $user->Address =$request->Address;
        $user->WorkType =$request->WorkType;
       
        $user->save();
		
       return view('login.index');
    }
	
    public function verify(Request $req){
    	
        $user = User::where('Email',$req->email)
        ->where('Password',$req->password)
        ->first();
        if($user != null){

            if($user->type=='worker'){

                $req->session()->put('Email',$req->email);
                return redirect()->route('worker.index');
            }
            if($user->type=='admin'){
				
                $req->session()->put('Email',$req->email);
                return redirect()->route('nonactive.index');
            }}
        else{
			//$req->session()->put('Email',$req->Email);
            //$req->session()->flash('msg','invalid username/password');
             //return redirect()->route('/login');
			   return redirect()->route('worker.index');
        }
    }
}
